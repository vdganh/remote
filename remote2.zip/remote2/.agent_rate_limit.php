<?php http_response_code(403); exit; ?>
{
    "127.0.0.1": [
        1780253190,
        1780253230
    ]
}