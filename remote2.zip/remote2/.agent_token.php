<?php http_response_code(403); exit; ?>
{
    "token": "ded0d68b7ed637e1d0e885cb5c3651bb"
}