<?php http_response_code(403); exit; ?>
{
    "79974ab3-a9d3-4dbb-934c-8a2a5a040b47": 1780253250,
    "f750b1d4-d991-49d3-83a1-9cade732774f": 1780253290
}